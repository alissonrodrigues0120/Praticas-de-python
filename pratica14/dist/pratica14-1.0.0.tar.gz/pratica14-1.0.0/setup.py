from distutils.core import setup

setup(
    name='pratica14',
    version = '1.0.0',
    py_modules = ['pratica14'],
    author = 'alisson',
    author_email= 'alissonrodriguesfernandes@gmail.com',
    description= 'um simples programa para printar listas dentro de listas',

)